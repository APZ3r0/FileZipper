import os
import zipfile
import subprocess
import sys
import threading
import sqlite3
from datetime import datetime, timezone

import sched
import http.server
import socketserver
import json
import webbrowser
from urllib.parse import urlparse, parse_qs
import time
from datetime import datetime, timezone, timedelta
import io
# endregion

import argparse

# region Optional Imports
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from PIL import Image, ImageTk
except ImportError:
    tk = None

try:
    import msal
    import requests
except ImportError:
    msal = None
# endregion

# This script provides a graphical and command-line interface for compressing files and folders into ZIP archives.
# It records metadata about each compressed file—such as its original path, size, and modification time—into an
# SQLite database. The script also includes functionality for searching the database, managing compression jobs,
# and optionally uploading archives to Microsoft OneDrive. It is designed to be self-contained, handling
# dependencies gracefully and defaulting to a CLI if GUI libraries are unavailable.
#
# Features:
# - GUI and CLI interfaces for file and folder compression.
# - SQLite database for tracking file metadata and compression jobs.
# - Search functionality to locate files within archives.
# - Job management for automating recurring compression tasks.
# - Optional integration with Microsoft OneDrive for cloud uploads.
# - Automatic extraction of location data from image files (if available).
# - Graceful fallback to CLI mode if GUI components are not installed.


# Optional libs for OneDrive (MS Graph)
try:
    import msal
except Exception:
    msal = None

try:

    import requests
except Exception:
    requests = None

# Robust workaround for older pydevd / debugpy sys_monitoring (pydevd 3.14.0)
try:
    if not hasattr(threading.Thread, "_handle"):
        threading.Thread._handle = None
    mt = threading.main_thread()
    if not hasattr(mt, "_handle"):
        mt._handle = None
except Exception:
    pass

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception:
    tk = None  # GUI won't be available in headless environments

# Database (records each file added to archives)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "filezipper_records.db")


def _init_db(path: str = DB_PATH) -> None:
    """Create DB and table if not present. If an older table exists, attempt to add the `location` and `description` columns."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL;")
        # Create table with location and description columns if it doesn't exist
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS zipped_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                original_path TEXT NOT NULL,
                arcname TEXT NOT NULL,
                zip_path TEXT NOT NULL,
                file_size INTEGER,
                mtime REAL,
                compressed_size INTEGER,
                location TEXT,
                description TEXT,
                recorded_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                source_path TEXT NOT NULL,
                destination_path TEXT NOT NULL,
                onedrive_upload INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS destinations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                location TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_arcname ON zipped_files(arcname);")
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_zip_path ON zipped_files(zip_path);"
        )
        conn.commit()
        # If an older DB exists without the 'location' or 'description' column, add them
        cur = conn.execute("PRAGMA table_info(zipped_files);")
        cols = [r[1] for r in cur.fetchall()]
        if "location" not in cols:
            try:
                conn.execute("ALTER TABLE zipped_files ADD COLUMN location TEXT;")
                conn.commit()
            except Exception:
                pass
        if "description" not in cols:
            try:
                conn.execute("ALTER TABLE zipped_files ADD COLUMN description TEXT;")
                conn.commit()
            except Exception:
                pass
        # Add status columns to jobs table if they don't exist
        cur = conn.execute("PRAGMA table_info(jobs);")
        cols = [r[1] for r in cur.fetchall()]
        if "status" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN status TEXT;")
                conn.commit()
            except Exception:
                pass
        if "last_run_at" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN last_run_at TEXT;")
                conn.commit()
            except Exception:
                pass
        if "last_run_status" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN last_run_status TEXT;")
                conn.commit()
            except Exception:
                pass
        if "schedule" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN schedule TEXT;")
                conn.commit()
            except Exception:
                pass
        if "next_run_at" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN next_run_at TEXT;")
                conn.commit()
            except Exception:
                pass
        if "schedule_hour" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN schedule_hour INTEGER;")
                conn.commit()
            except Exception:
                pass
        if "schedule_minute" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN schedule_minute INTEGER;")
                conn.commit()
            except Exception:
                pass
        if "schedule_date" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN schedule_date TEXT;")
                conn.commit()
            except Exception:
                pass
        if "move_files" not in cols:
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN move_files INTEGER NOT NULL DEFAULT 0;")
                conn.commit()
            except Exception:
                pass
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _record_file(
    original_path: str,
    arcname: str,
    zip_path: str,
    file_size: int | None,
    mtime: float | None,
    compressed_size: int | None,
    location: str | None = None,
    description: str | None = None,
    path: str = DB_PATH,
) -> None:
    """Insert a file record into the DB. Best-effort; do not raise on DB errors."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute(
            """
            INSERT INTO zipped_files
                (original_path, arcname, zip_path, file_size, mtime, compressed_size, location, description, recorded_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                os.path.abspath(original_path),
                arcname,
                os.path.abspath(zip_path),
                file_size,
                mtime,
                compressed_size,
                location,
                description,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        conn.commit()
    except Exception:
        # keep primary operation (zipping) unaffected
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass


def search_files(query: str, limit: int = 200, path: str = DB_PATH):
    """Search the DB for arcname/original_path substrings (case-insensitive). Returns rows including location and description."""
    like = f"%{query}%"
    try:
        conn = sqlite3.connect(path, timeout=30)
        if not query:
            cur = conn.execute(
                """
                SELECT original_path, arcname, zip_path, file_size, mtime, compressed_size, location, description, recorded_at
                FROM zipped_files
                ORDER BY recorded_at DESC
                LIMIT ?
                """,
                (limit,),
            )
        else:
            cur = conn.execute(
                """
                SELECT original_path, arcname, zip_path, file_size, mtime, compressed_size, location, description, recorded_at
                FROM zipped_files
                WHERE arcname LIKE ? OR original_path LIKE ?
                COLLATE NOCASE
                ORDER BY recorded_at DESC
                LIMIT ?
                """,
                (like, like, limit),
            )
        rows = cur.fetchall()
        return rows
    except Exception:
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass


def add_job(
    name: str,
    source_path: str,
    destination_path: str,
    onedrive_upload: bool,
    move_files: bool,
    schedule: str,
    schedule_hour: int | None = None,
    schedule_minute: int | None = None,
    schedule_date: str | None = None,
    path: str = DB_PATH,
) -> None:
    """Add a new job to the database."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        now = datetime.now(timezone.utc)
        next_run_at = None
        if schedule == "Daily":
            next_run_at = (now + timedelta(days=1)).replace(hour=schedule_hour, minute=schedule_minute, second=0, microsecond=0)
        elif schedule == "Hourly":
            next_run_at = (now + timedelta(hours=1)).replace(minute=schedule_minute, second=0, microsecond=0)
        elif schedule == "Once" and schedule_date:
            dt = datetime.strptime(schedule_date, "%Y-%m-%d")
            next_run_at = dt.replace(hour=schedule_hour, minute=schedule_minute, second=0, microsecond=0)

        conn.execute(
            """
            INSERT INTO jobs (name, source_path, destination_path, onedrive_upload, move_files, created_at, status, schedule, next_run_at, schedule_hour, schedule_minute, schedule_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                name,
                os.path.abspath(source_path),
                os.path.abspath(destination_path),
                1 if onedrive_upload else 0,
                1 if move_files else 0,
                now.isoformat(),
                "Idle",
                schedule,
                next_run_at.isoformat() if next_run_at else None,
                schedule_hour,
                schedule_minute,
                schedule_date,
            ),
        )
        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass


def add_destination(name: str, location: str, path: str = DB_PATH) -> None:
    """Add a new destination to the database."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute(
            """
            INSERT INTO destinations (name, location)
            VALUES (?, ?)
            """,
            (name, os.path.abspath(location)),
        )
        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass


import sched


def update_job_status(
    job_id: int,
    status: str,
    last_run_at: str | None,
    last_run_status: str | None,
    next_run_at: str | None = None,
    path: str = DB_PATH,
) -> None:
    """Update the status of a job."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute(
            "UPDATE jobs SET status = ?, last_run_at = ?, last_run_status = ?, next_run_at = ? WHERE id = ?",
            (status, last_run_at, last_run_status, next_run_at, job_id),
        )
        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass



def delete_job(job_name: str, path: str = DB_PATH) -> None:
    """Delete a job from the database by name."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute("DELETE FROM jobs WHERE name = ?", (job_name,))
        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass


def delete_destination(name: str, path: str = DB_PATH) -> None:
    """Delete a destination from the database by name."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        conn.execute("DELETE FROM destinations WHERE name = ?", (name,))
        conn.commit()
    finally:
        try:
            conn.close()
        except Exception:
            pass


def list_jobs(path: str = DB_PATH) -> list:
    """List all jobs from the database."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        cur = conn.execute(
            "SELECT id, name, source_path, destination_path, onedrive_upload, move_files, created_at, status, last_run_at, last_run_status, schedule, next_run_at, schedule_hour, schedule_minute, schedule_date FROM jobs ORDER BY name"
        )
        rows = cur.fetchall()
        return rows
    except Exception:
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass


def list_destinations(path: str = DB_PATH) -> list:
    """List all destinations from the database."""
    try:
        conn = sqlite3.connect(path, timeout=30)
        cur = conn.execute("SELECT id, name, location FROM destinations ORDER BY name")
        rows = cur.fetchall()
        return rows
    except Exception:
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _is_image_file(path: str) -> bool:
    """Return True if path has an image file extension."""
    if not path:
        return False
    lower = path.lower()
    return any(
        lower.endswith(ext)
        for ext in (".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff", ".tif", ".heic")
    )


def resolve_save_conflict(zip_dest: str, on_conflict_action: str | None = None) -> str | None:
    """
    Check if a zip file already exists and prompt the user to resolve the conflict.

    Args:
        zip_dest: The destination path for the zip file.
        on_conflict_action: Predefined action for conflict resolution ('overwrite', 'rename', 'cancel').

    Returns:
        The new path for the zip file, or None if the operation should be cancelled.
    """
    if not os.path.exists(zip_dest):
        return zip_dest

    # If action is provided, use it
    if on_conflict_action:
        response = on_conflict_action.lower()
        if response == "overwrite":
            return zip_dest
        elif response == "rename":
            count = 1
            while True:
                name, ext = os.path.splitext(zip_dest)
                new_dest = f"{name}_{count}{ext}"
                if not os.path.exists(new_dest):
                    return new_dest
                count += 1
        elif response == "cancel":
            return None

    
    # In a GUI environment, show a dialog
    if tk:
        response = messagebox.askyesnocancel(
            "File Exists",
            f"The file '{os.path.basename(zip_dest)}' already exists. Do you want to overwrite it?",
        )
        if response is True:  # Yes (Overwrite)
            return zip_dest
        elif response is False:  # No (Rename)
            count = 1
            while True:
                name, ext = os.path.splitext(zip_dest)
                new_dest = f"{name}_{count}{ext}"
                if not os.path.exists(new_dest):
                    return new_dest
                count += 1
        else:  # Cancel
            return None
    # In a CLI environment, prompt the user
    else:
        while True:
            response = input(
                f"The file '{os.path.basename(zip_dest)}' already exists. [O]verwrite, [R]ename, or [C]ancel? "
            ).lower()
            if response in ("o", "overwrite"):
                return zip_dest
            elif response in ("r", "rename"):
                count = 1
                while True:
                    name, ext = os.path.splitext(zip_dest)
                    new_dest = f"{name}_{count}{ext}"
                    if not os.path.exists(new_dest):
                        return new_dest
                    count += 1
            elif response in ("c", "cancel"):
                return None


# ensure DB exists
_init_db()


# ---------------- OneDrive / Microsoft Graph helpers ----------------
# Requirements:
#  - set environment variable MSAL_CLIENT_ID to your Azure AD app (Public client) client id
#  - install dependencies: pip install msal requests
# Uses device code flow to obtain a token interactively.
ONEDRIVE_SCOPES = ["Files.ReadWrite.All", "offline_access", "User.Read"]


def _ensure_onedrive_deps():
    if msal is None:
        raise RuntimeError(
            "msal is required for OneDrive integration. Install with: pip install msal"
        )
    if requests is None:
        raise RuntimeError(
            "requests is required for OneDrive integration. Install with: pip install requests"
        )


def acquire_onedrive_token(scopes: list[str] | None = None) -> str:
    """Acquire an access token via device code flow. Requires MSAL_CLIENT_ID env var."""
    _ensure_onedrive_deps()
    client_id = os.environ.get("MSAL_CLIENT_ID")
    if not client_id:
        raise RuntimeError(
            "Set MSAL_CLIENT_ID environment variable to your Azure AD app client id."
        )
    scopes = scopes or ONEDRIVE_SCOPES
    app = msal.PublicClientApplication(client_id)
    flow = app.initiate_device_flow(scopes=scopes)
    if "message" in flow:
        # Present the code to the user in console (device code flow)
        print(flow["message"])
    else:
        raise RuntimeError("Failed to start device flow for authentication.")
    # msal handles polling internally; returns token dict or None
    result = app.acquire_token_by_device_flow(flow)
    if not result or "access_token" not in result:
        raise RuntimeError(
            f"Authentication failed: {result.get('error_description') if result else 'unknown'}"
        )
    return result["access_token"]


def _simple_put_upload(local_path: str, remote_path: str, access_token: str) -> dict:
    """Small-file upload using simple PUT to /me/drive/root:/path:/content"""
    url = f"https://graph.microsoft.com/v1.0/me/drive/root:/{remote_path}:/content"
    headers = {"Authorization": f"Bearer {access_token}"}
    with open(local_path, "rb") as f:
        resp = requests.put(url, headers=headers, data=f)
    resp.raise_for_status()
    return resp.json()


def _create_upload_session(remote_path: str, access_token: str) -> str:
    url = f"https://graph.microsoft.com/v1.0/me/drive/root:/{remote_path}:/createUploadSession"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    resp = requests.post(
        url,
        headers=headers,
        json={"item": {"@microsoft.graph.conflictBehavior": "rename"}},
    )
    resp.raise_for_status()
    data = resp.json()
    return data["uploadUrl"]


def _chunked_upload(local_path: str, upload_url: str) -> dict:
    total_size = os.path.getsize(local_path)
    chunk_size = 320 * 1024  # 320 KiB
    with open(local_path, "rb") as f:
        start = 0
        while start < total_size:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            end = start + len(chunk) - 1
            headers = {
                "Content-Length": str(len(chunk)),
                "Content-Range": f"bytes {start}-{end}/{total_size}",
            }
            resp = requests.put(upload_url, headers=headers, data=chunk)
            if resp.status_code in (200, 201):
                return resp.json()
            if resp.status_code == 202:
                # accepted; continue
                start = end + 1
                continue
            # unexpected error
            resp.raise_for_status()
    raise RuntimeError("Chunked upload did not complete successfully.")


def upload_file_to_onedrive(local_path: str, remote_path: str, access_token: str) -> dict:
    """
    Upload a local file to OneDrive under the given remote path (path relative to root).
    Uses simple PUT for files < 4MB, upload session for larger files.
    Returns Graph response JSON on success.
    """
    _ensure_onedrive_deps()
    size = os.path.getsize(local_path)
    if size < 4 * 1024 * 1024:
        return _simple_put_upload(local_path, remote_path, access_token)
    # large file - create upload session and upload in chunks
    upload_url = _create_upload_session(remote_path, access_token)
    return _chunked_upload(local_path, upload_url)


# ---------------- End OneDrive helpers ----------------


def _generate_image_description(path: str) -> str | None:
    """Generate an image caption/description using local transformers if available or HuggingFace Inference API as fallback.

    Environment:
    - Optional local: `transformers`, `torch` (will load `Salesforce/blip-image-captioning-base`)
    - Fallback: set environment variable `HF_API_TOKEN` with your Hugging Face token to call the inference API
    """
    # try local transformers + PIL
    try:
        from PIL import Image
    except Exception:
        Image = None

    # local model
    try:
        if Image is not None:
            try:
                from transformers import BlipProcessor, BlipForConditionalGeneration
                import torch
                img = Image.open(path).convert("RGB")
                processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
                model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
                inputs = processor(images=img, return_tensors="pt")
                if torch.cuda.is_available():
                    model.to("cuda")
                    inputs = {k: v.to("cuda") for k, v in inputs.items()}
                out = model.generate(**inputs)
                caption = processor.decode(out[0], skip_special_tokens=True)
                if caption and caption.strip():
                    return caption.strip()
            except Exception:
                # local transformers not available or failed; fall through to HF API
                pass
    except Exception:
        pass

    # Fallback to Hugging Face Inference API
    hf_token = os.environ.get("HF_API_TOKEN")
    if hf_token and requests is not None:
        try:
            api_url = "https://api-inference.huggingface.co/models/Salesforce/blip-image-captioning-base"
            headers = {"Authorization": f"Bearer {hf_token}"}
            with open(path, "rb") as f:
                data = f.read()
            resp = requests.post(api_url, headers=headers, data=data, timeout=60)
            if resp.status_code == 200:
                # API returns text or JSON depending; try parsing
                try:
                    j = resp.json()
                    if isinstance(j, dict) and "generated_text" in j:
                        txt = j["generated_text"]
                    elif isinstance(j, list) and len(j) > 0 and isinstance(j[0], dict) and "generated_text" in j[0]:
                        txt = j[0]["generated_text"]
                    else:
                        # fallback to text
                        txt = resp.text
                except Exception:
                    txt = resp.text
                if txt and isinstance(txt, str) and txt.strip():
                    return txt.strip()
        except Exception:
            pass

    return None


def _extract_location_from_file(path: str) -> str | None:
    """Attempt to extract a location string from file metadata.

    Strategies (best-effort):
    - Try Pillow EXIF first (GPS or textual tags).
    - If that yields nothing, try `exifread` as a fallback (broader EXIF support).
    Returns a string like 'lat,lon' or textual location when available, otherwise None.
    """
    if not _is_image_file(path):
        return None
    # --- Try Pillow EXIF first ---
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS
    except Exception:
        Image = None

    if Image is not None:
        try:
            img = Image.open(path)
            exif = img._getexif() or {}
        except Exception:
            exif = {}

        try:
            # normalize exif tag names
            exif_named = {}
            for tag_id, value in exif.items():
                name = TAGS.get(tag_id, tag_id)
                exif_named[name] = value

            # Check some common textual tags
            for key in ("City", "ImageDescription", "XPTitle", "XPSubject", "XPComment", "XPKeywords", "Artist"):
                val = exif_named.get(key)
                if val:
                    # XP* tags may be bytes; try decode
                    if isinstance(val, bytes):
                        try:
                            val = val.decode("utf-16-le", errors="ignore").rstrip("\x00")
                        except Exception:
                            try:
                                val = val.decode(errors="ignore")
                            except Exception:
                                val = None
                    if isinstance(val, str) and val.strip():
                        return val.strip()

            # Handle GPS
            gps = exif_named.get("GPSInfo")
            if gps:
                gps_data = {}
                if isinstance(gps, dict):
                    for k, v in gps.items():
                        name = GPSTAGS.get(k, k)
                        gps_data[name] = v

                def _convert_to_degrees(value):
                    try:
                        d = value[0][0] / value[0][1]
                        m = value[1][0] / value[1][1]
                        s = value[2][0] / value[2][1]
                        return d + (m / 60.0) + (s / 3600.0)
                    except Exception:
                        return None

                lat_val = gps_data.get("GPSLatitude")
                lat_ref = gps_data.get("GPSLatitudeRef")
                lon_val = gps_data.get("GPSLongitude")
                lon_ref = gps_data.get("GPSLongitudeRef")
                if lat_val and lon_val:
                    lat = _convert_to_degrees(lat_val)
                    lon = _convert_to_degrees(lon_val)
                    if lat is not None and lon is not None:
                        if isinstance(lat_ref, bytes):
                            try:
                                lat_ref = lat_ref.decode()
                            except Exception:
                                pass
                        if isinstance(lon_ref, bytes):
                            try:
                                lon_ref = lon_ref.decode()
                            except Exception:
                                pass
                        if lat_ref and str(lat_ref).upper() == "S":
                            lat = -lat
                        if lon_ref and str(lon_ref).upper() == "W":
                            lon = -lon
                        return f"{lat:.6f},{lon:.6f}"
        except Exception:
            # Pillow parsing failed; fall through to exifread fallback
            pass

    # --- Fallback: try exifread for broader EXIF tag coverage ---
    try:
        import exifread
    except Exception:
        exifread = None

    if exifread is not None:
        try:
            with open(path, "rb") as f:
                tags = exifread.process_file(f, details=False)

            # text tags
            for key in ("Image ImageDescription", "Image XPTitle", "Image XPComment", "EXIF UserComment", "Image XPKeywords"):
                val = tags.get(key)
                if val:
                    s = str(val)
                    if s.strip():
                        return s.strip()

            # GPS tags
            lat_tag = tags.get("GPS GPSLatitude")
            lat_ref = tags.get("GPS GPSLatitudeRef")
            lon_tag = tags.get("GPS GPSLongitude")
            lon_ref = tags.get("GPS GPSLongitudeRef")

            def _to_degrees_exifread(tagval):
                try:
                    # tagval.values often contains Ratio objects
                    vals = []
                    if hasattr(tagval, "values"):
                        for v in tagval.values:
                            try:
                                vals.append(float(v.num) / float(v.den))
                            except Exception:
                                try:
                                    vals.append(float(v))
                                except Exception:
                                    pass
                    else:
                        # fallback: try parsing string
                        s = str(tagval)
                        s = s.replace("deg", " ")
                        s = s.replace("\u00b0", " ")  # degree symbol
                        s = s.replace("'", " ")
                        s = s.replace('"', " ")
                        parts = s.split()
                        for p in parts:
                            try:
                                vals.append(float(p))
                            except Exception:
                                pass
                    if not vals:
                        return None
                    d = vals[0]
                    m = vals[1] if len(vals) > 1 else 0
                    s = vals[2] if len(vals) > 2 else 0
                    return d + (m / 60.0) + (s / 3600.0)
                except Exception:
                    return None

            if lat_tag and lon_tag:
                lat = _to_degrees_exifread(lat_tag)
                lon = _to_degrees_exifread(lon_tag)
                if lat is not None and lon is not None:
                    try:
                        if lat_ref and str(lat_ref).upper().startswith("S"):
                            lat = -lat
                        if lon_ref and str(lon_ref).upper().startswith("W"):
                            lon = -lon
                    except Exception:
                        pass
                    return f"{lat:.6f},{lon:.6f}"
        except Exception:
            pass

    return None


def zip_path(target_path: str, output_root: str | None = None, on_conflict_action: str | None = None) -> str | None:
    """Create a zip archive of a file or directory, record each entry in DB, and open output folder on Windows.

    If `output_root` is provided it should be a directory path where the resulting zip will be placed.
    If omitted, the default is a `Zipped` directory next to this script.
    Returns the full path to the created zip file.
    """
    base = os.path.abspath(os.path.dirname(__file__))
    if output_root:
        output_root = os.path.abspath(output_root)
    else:
        output_root = os.path.join(base, "Zipped")
    os.makedirs(output_root, exist_ok=True)

    name = os.path.basename(target_path.rstrip(os.sep)) or "archive"
    zip_dest_initial = os.path.join(output_root, f"{name}.zip")
    
    zip_dest = zip_dest_initial
    action = "created"
    if os.path.exists(zip_dest_initial):
        if on_conflict_action:
            if on_conflict_action == "overwrite":
                action = "overwritten"
            elif on_conflict_action == "rename":
                zip_dest = resolve_save_conflict(zip_dest_initial, on_conflict_action="rename")
                if zip_dest is None:
                    return "cancelled", None
                action = "renamed"
            elif on_conflict_action == "cancel":
                return "cancelled", None
        else: # Interactive
            zip_dest = resolve_save_conflict(zip_dest_initial, on_conflict_action=None)
            if zip_dest is None:
                return "cancelled", None
            elif zip_dest != zip_dest_initial:
                action = "renamed"
            else:
                action = "overwritten"



    with zipfile.ZipFile(zip_dest, "w", zipfile.ZIP_DEFLATED) as zipf:
        if os.path.isdir(target_path):
            for root, _, files in os.walk(target_path):
                for f in files:
                    fp = os.path.join(root, f)
                    arc = os.path.relpath(fp, start=target_path)
                    try:
                        zipf.write(fp, arc)
                        info = zipf.getinfo(arc)
                        file_size = info.file_size
                        compressed_size = info.compress_size
                    except Exception:
                        file_size = os.path.getsize(fp) if os.path.exists(fp) else None
                        compressed_size = None
                    try:
                        mtime = os.path.getmtime(fp) if os.path.exists(fp) else None
                    except Exception:
                        mtime = None

                    # extract location metadata (best-effort)
                    try:
                        location = _extract_location_from_file(fp)
                    except Exception:
                        location = None

                    # generate image description (if image file)
                    description = None
                    try:
                        if _is_image_file(fp):
                            description = _generate_image_description(fp)
                    except Exception:
                        description = None

                    _record_file(original_path=fp,
                                 arcname=arc,
                                 zip_path=zip_dest,
                                 file_size=file_size,
                                 mtime=mtime,
                                 compressed_size=compressed_size,
                                 location=location,
                                 description=description)
        else:
            try:
                zipf.write(target_path, arcname=name)
                info = zipf.getinfo(name)
                file_size = info.file_size
                compressed_size = info.compress_size
            except Exception:
                file_size = os.path.getsize(target_path) if os.path.exists(target_path) else None
                compressed_size = None
            try:
                mtime = os.path.getmtime(target_path) if os.path.exists(target_path) else None
            except Exception:
                mtime = None

            try:
                location = _extract_location_from_file(target_path)
            except Exception:
                location = None

            description = None
            try:
                if _is_image_file(target_path):
                    description = _generate_image_description(target_path)
            except Exception:
                description = None

            _record_file(original_path=target_path,
                         arcname=name,
                         zip_path=zip_dest,
                         file_size=file_size,
                         mtime=mtime,
                         compressed_size=compressed_size,
                         location=location,
                         description=description)

    # Auto-open folder on Windows
    # if sys.platform.startswith("win"):
    #     try:
    #         os.startfile(os.path.abspath(output_root))
    #     except Exception:
    #         subprocess.run(["explorer", os.path.abspath(output_root)])
    return action, zip_dest


# ---------- Model Context Protocol (MCP) over HTTP Server ----------
MCP_PORT = 8999

class MCPRequestHandler(http.server.BaseHTTPRequestHandler):
    """Handles HTTP requests for the Model Context Protocol."""

    def do_GET(self):
        """Handle GET requests to expose application data model."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        try:
            if path == '/files':
                search_query = query_params.get('search', [''])[0]
                data = search_files(search_query)
                self.send_json_response(data)
            elif path == '/jobs':
                data = list_jobs()
                self.send_json_response(data)
            elif path == '/destinations':
                data = list_destinations()
                self.send_json_response(data)
            else:
                self.send_error(404, "Not Found")
        except Exception as e:
            self.send_error(500, f"Internal Server Error: {e}")

    def send_json_response(self, data, status_code=200):
        """Sends a JSON response."""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        # Use a custom default to handle non-serializable types like datetime
        json_str = json.dumps(data, indent=2, default=str).encode('utf-8')
        self.wfile.write(json_str)

    def log_message(self, format, *args):
        """Suppress HTTP server logging to keep the console clean."""
        return

def start_mcp_server(port=MCP_PORT):
    """Starts the MCP HTTP server in a separate thread."""
    def run_server():
        with socketserver.TCPServer(("", port), MCPRequestHandler) as httpd:
            # This print is useful for confirming the server started.
            print(f"MCP server running on http://localhost:{port}")
            httpd.serve_forever()

    server_thread = threading.Thread(target=run_server)
    server_thread.daemon = True  # Allows main program to exit even if thread is running
    server_thread.start()


def _run_scheduler(root_widget, status_variable, active_threads, active_threads_lock):
    """
    A persistent scheduler that runs in a background thread.
    It uses the `sched` module to run jobs at their scheduled time.
    """
    scheduler = sched.scheduler(time.time, time.sleep)

    def schedule_job(job):
        """Helper to schedule a single job."""
        job_id, name, _, _, _, _, _, _, _, schedule, next_run_at_str = job
        if next_run_at_str:
            try:
                next_run_at = datetime.fromisoformat(next_run_at_str)
                now = datetime.now(timezone.utc)
                
                # Make sure next_run_at is timezone-aware for comparison
                if next_run_at.tzinfo is None:
                    next_run_at = next_run_at.replace(tzinfo=timezone.utc)

                if next_run_at > now:
                    delay = (next_run_at - now).total_seconds()
                    scheduler.enter(delay, 1, run_job, argument=(job,))
            except (ValueError, TypeError):
                # Handle cases where next_run_at_str is not a valid ISO format string
                pass


    def run_job(job):
        """The function executed by the scheduler."""
        job_id, name, source_path, dest_path, onedrive, _, _, _, _, schedule, _, schedule_hour, schedule_minute, schedule_date = job
        
        # To ensure GUI updates happen on the main thread, use `after`
        root_widget.after(0, status_variable.set, f"Auto-running {schedule.lower()} job: {name}")
        
        upload = (onedrive == 1)
        # Run the actual zip/upload logic in a new thread to avoid blocking the scheduler
        t = threading.Thread(target=_run_zip_thread, args=(source_path, root_widget, status_variable, upload, dest_path, job_id, schedule, schedule_hour, schedule_minute, schedule_date))
        t.daemon = False
        with active_threads_lock:
            active_threads.add(t)
        t.start()

        # Reschedule the job for its next run
        # This is now handled within _run_zip_thread calling update_job_status
        # But we need to fetch the updated job to get the new next_run_at
        
        # Let's re-fetch all jobs and update the schedule.
        # This is simpler than trying to manage individual job updates in the scheduler loop.
        # The scheduler will be re-populated in the main loop.


    def scheduler_loop():
        while True:
            # Re-populate the scheduler with all jobs
            try:
                jobs = list_jobs()
                for job in jobs:
                    schedule_job(job)
                
                # Run pending jobs
                scheduler.run(blocking=False)

            except Exception:
                # Log errors if necessary
                pass
            
            # Sleep for a bit to avoid busy-waiting
            time.sleep(60)

    # Start the scheduler loop in a daemon thread
    scheduler_thread = threading.Thread(target=scheduler_loop)
    scheduler_thread.daemon = True
    scheduler_thread.start()


# ---------- GUI ----------
def run_gui():
    if tk is None:
        raise RuntimeError("Tkinter is not available in this environment.")

    root = tk.Tk()
    root.title("FileZipper")
    root.geometry("800x700") # Increased height
    root.configure(bg="#e6ffe6")

    source_var = tk.StringVar()
    status_var = tk.StringVar(value="Ready.")
    onedrive_var = tk.BooleanVar(value=False)
    dest_var = tk.StringVar(value=os.path.join(BASE_DIR, "Zipped"))

    active_threads = set()
    active_threads_lock = threading.Lock()
    shutting_down = False

    def browse_folder():
        path = filedialog.askdirectory(title="Select Folder to Zip")
        if path:
            source_var.set(path)

    def browse_destination():
        path = filedialog.askdirectory(title="Select Destination Folder for Zip")
        if path:
            dest_var.set(path)

    def compress():
        nonlocal shutting_down
        if shutting_down:
            return
        path = source_var.get().strip()
        if not path or not os.path.exists(path):
            messagebox.showerror("Error", "Please select a valid folder or file.")
            return

        status_var.set("Compressing.")
        t = threading.Thread(target=_run_zip_thread, args=(path, root, status_var, onedrive_var.get(), dest_var.get()))
        t.daemon = False
        with active_threads_lock:
            active_threads.add(t)
        t.start()

    def _run_zip_thread(path, root_widget, status_variable, upload_to_onedrive, output_root, job_id=None, schedule=None, schedule_hour=None, schedule_minute=None, schedule_date=None, move_files=False):
        if job_id:
            root_widget.after(0, update_job_status, job_id, "Running", None, None, None)
            root_widget.after(0, _refresh_jobs_list)

        last_run_time = datetime.now(timezone.utc)
        next_run_at = None
        if schedule == "Daily":
            next_run_at = (last_run_time + timedelta(days=1)).replace(hour=schedule_hour, minute=schedule_minute, second=0, microsecond=0)
        elif schedule == "Hourly":
            next_run_at = (last_run_time + timedelta(hours=1)).replace(minute=schedule_minute, second=0, microsecond=0)
        
        next_run_at_iso = next_run_at.isoformat() if next_run_at else None

        try:
            action, dest = zip_path(path, output_root)
            if action == "cancelled":
                root_widget.after(0, status_variable.set, "Operation cancelled.")
                if job_id:
                    root_widget.after(0, update_job_status, job_id, "Idle", last_run_time.isoformat(), "Cancelled", next_run_at_iso)
                return
            
            if move_files:
                try:
                    if os.path.isdir(path):
                        import shutil
                        shutil.rmtree(path)
                    else:
                        os.remove(path)
                    root_widget.after(0, status_variable.set, f"Moved files to {dest}")
                except Exception as e:
                    root_widget.after(0, status_variable.set, f"Error deleting files: {e}")
            
            root_widget.after(0, dest_var.set, os.path.abspath(os.path.dirname(dest)))
            if upload_to_onedrive:
                try:
                    token = acquire_onedrive_token()
                    remote = f"Zipped/{os.path.basename(dest)}"
                    upload_file_to_onedrive(dest, remote, token)
                    root_widget.after(0, status_variable.set, f"Uploaded to OneDrive: {remote}")
                    if job_id:
                         root_widget.after(0, update_job_status, job_id, "Idle" if schedule != "Once" else "Completed", last_run_time.isoformat(), "Success", next_run_at_iso)
                except Exception as e:
                    root_widget.after(0, status_variable.set, f"Zip created but OneDrive upload failed: {e}")
                    if job_id:
                        root_widget.after(0, update_job_status, job_id, "Idle", last_run_time.isoformat(), "Failed", next_run_at_iso)
            else:
                if action == "created":
                    root_widget.after(0, status_variable.set, f"Completed: {dest}")
                elif action == "overwritten":
                    root_widget.after(0, status_variable.set, f"Overwritten: {dest}")
                elif action == "renamed":
                    root_widget.after(0, status_variable.set, f"Renamed: {dest}")
                if job_id:
                    root_widget.after(0, update_job_status, job_id, "Idle" if schedule != "Once" else "Completed", last_run_time.isoformat(), "Success", next_run_at_iso)
        except Exception as e:
            root_widget.after(0, status_variable.set, f"Error: {e}")
            if job_id:
                root_widget.after(0, update_job_status, job_id, "Idle", last_run_time.isoformat(), "Failed", next_run_at_iso)
        finally:
            cur = threading.current_thread()
            with active_threads_lock:
                active_threads.discard(cur)
            # Refresh the file and job lists
            root_widget.after(0, _do_main_search, "", db_results_tree)
            if job_id:
                root_widget.after(0, _refresh_jobs_list)



    def _open_create_destination_window():
        dest_win = tk.Toplevel(root)
        dest_win.title("Create New Destination")
        dest_win.geometry("600x400")
        dest_win.configure(bg="#f7f7f7")

        # Frame for Destination Name
        name_frame = tk.LabelFrame(dest_win, text="Enter Destination Name", bg="#f7f7f7", padx=10, pady=10)
        name_frame.pack(padx=10, pady=10, fill="x")

        tk.Label(name_frame, text="Named Destination:", bg="#f7f7f7").grid(row=0, column=0, sticky="w")
        dest_name_var = tk.StringVar()
        tk.Entry(name_frame, textvariable=dest_name_var, width=40).grid(row=0, column=1, padx=5)

        # Frame for Destination Path
        path_frame = tk.LabelFrame(dest_win, text="Enter Destination", bg="#f7f7f7", padx=10, pady=10)
        path_frame.pack(padx=10, pady=10, fill="x")

        tk.Label(path_frame, text="Path:", bg="#f7f7f7").grid(row=0, column=0, sticky="w")
        dest_path_var = tk.StringVar()
        tk.Entry(path_frame, textvariable=dest_path_var, width=40).grid(row=0, column=1, padx=5)
        def browse_dest_path():
            path = filedialog.askdirectory(title="Select Destination Location")
            if path:
                dest_path_var.set(path)
        tk.Button(path_frame, text="Browse...", command=browse_dest_path).grid(row=0, column=2, padx=5)

        # --- Existing Destinations Display ---
        dest_list_frame = tk.LabelFrame(dest_win, text="Existing Destinations", bg="#f7f7f7", padx=10, pady=10)
        dest_list_frame.pack(padx=10, pady=10, fill="both", expand=True)

        dest_cols = ("name", "location")
        dest_tree = ttk.Treeview(dest_list_frame, columns=dest_cols, show="headings", height=5)
        dest_tree.heading("name", text="Name")
        dest_tree.heading("location", text="Location")
        dest_tree.column("name", width=150, anchor="w")
        dest_tree.column("location", width=350, anchor="w")

        dest_vscroll = ttk.Scrollbar(dest_list_frame, orient=tk.VERTICAL, command=dest_tree.yview)
        dest_tree.configure(yscrollcommand=dest_vscroll.set)
        dest_vscroll.pack(side=tk.RIGHT, fill="y")
        dest_tree.pack(fill="both", expand=True)

        original_name_to_edit = None

        def _edit_selected_destination(tree):
            nonlocal original_name_to_edit
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showinfo("Info", "Select a destination to edit.", parent=dest_win)
                return

            item_values = tree.item(selected_item[0], "values")
            name, location = item_values[0], item_values[1]
            
            dest_name_var.set(name)
            dest_path_var.set(location)
            original_name_to_edit = name

        def _delete_selected_destination(tree):
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showinfo("Info", "Select a destination to delete.", parent=dest_win)
                return

            item_values = tree.item(selected_item[0], "values")
            dest_name = item_values[0]

            if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the destination '{dest_name}'?", parent=dest_win):
                try:
                    delete_destination(dest_name)
                    _refresh_destinations_list(tree)
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to delete destination: {e}", parent=dest_win)

        dest_button_frame = tk.Frame(dest_list_frame, bg="#f7f7f7")
        dest_button_frame.pack(fill="x", pady=(5,0))
        tk.Button(dest_button_frame, text="Edit Selected", command=lambda: _edit_selected_destination(dest_tree)).pack(side=tk.RIGHT, padx=(0, 5))
        tk.Button(dest_button_frame, text="Delete Selected", command=lambda: _delete_selected_destination(dest_tree)).pack(side=tk.RIGHT)

        def _refresh_destinations_list(tree):
            for i in tree.get_children():
                tree.delete(i)
            destinations = list_destinations()
            for dest in destinations:
                _, name, location = dest
                tree.insert("", "end", values=(name, location))

        # Initial load
        _refresh_destinations_list(dest_tree)

        def _save_destination():
            nonlocal original_name_to_edit
            name = dest_name_var.get().strip()
            location = dest_path_var.get().strip()
            if not name or not location:
                messagebox.showerror("Error", "Both name and location are required.", parent=dest_win)
                return
            
            try:
                if original_name_to_edit:
                    # If we are editing, delete the old one first
                    delete_destination(original_name_to_edit)
                
                add_destination(name, location)
                messagebox.showinfo("Success", f"Destination '{name}' saved.", parent=dest_win)
                _refresh_destinations_list(dest_tree)
                dest_name_var.set("")
                dest_path_var.set("")
                original_name_to_edit = None # Reset edit state
            except sqlite3.IntegrityError:
                 messagebox.showerror("Error", "A destination with this name already exists.", parent=dest_win)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save destination: {e}", parent=dest_win)

        button_frame = tk.Frame(dest_win, bg="#f7f7f7")
        button_frame.pack(fill="x", side=tk.BOTTOM, pady=5)
        tk.Button(button_frame, text="Save", command=_save_destination).pack(side=tk.RIGHT, padx=10)
        tk.Button(button_frame, text="Cancel", command=dest_win.destroy).pack(side=tk.RIGHT)

        dest_win.transient(root)
        dest_win.grab_set()
        root.wait_window(dest_win)

    def _on_close():
        nonlocal shutting_down
        shutting_down = True
        try:
            for child in root.winfo_children():
                try:
                    child.configure(state="disabled")
                except Exception:
                    pass
        except Exception:
            pass
        with active_threads_lock:
            threads = list(active_threads)
        for t in threads:
            try:
                t.join(timeout=5.0)
            except Exception:
                pass
        try:
            root.destroy()
        except Exception:
            pass

    def _open_search_window():
        win = tk.Toplevel(root)
        win.title("Search zipped files")
        win.geometry("1000x480")
        win.configure(bg="#f7f7f7")

        tk.Label(win, text="Search term (filename or path substring):", bg="#f7f7f7").pack(anchor="w", padx=8, pady=(8, 0))
        query_var = tk.StringVar()
        qframe = tk.Frame(win, bg="#f7f7f7")
        qframe.pack(fill="x", padx=8)
        tk.Entry(qframe, textvariable=query_var, width=64).pack(side=tk.LEFT, padx=(0, 6))
        tk.Button(qframe, text="Search", command=lambda: _do_search(query_var.get(), results_tree)).pack(side=tk.LEFT)

        columns = ("arcname", "zip_name", "original", "size", "mtime", "recorded", "location", "description", "zip_path")
        results_tree = ttk.Treeview(win, columns=columns, show="headings")
        results_tree.heading("arcname", text="Name")
        results_tree.heading("zip_name", text="Archive")
        results_tree.heading("original", text="Original Path")
        results_tree.heading("size", text="Size")
        results_tree.heading("mtime", text="Modified")
        results_tree.heading("recorded", text="Recorded")
        results_tree.heading("location", text="Location")
        results_tree.heading("description", text="Description")
        results_tree.heading("zip_path", text="zip_path")

        results_tree.column("arcname", width=200, anchor="w")
        results_tree.column("zip_name", width=160, anchor="w")
        results_tree.column("original", width=320, anchor="w")
        results_tree.column("size", width=80, anchor="center")
        results_tree.column("mtime", width=140, anchor="center")
        results_tree.column("recorded", width=180, anchor="center")
        results_tree.column("location", width=200, anchor="w")
        results_tree.column("description", width=300, anchor="w")
        results_tree.column("zip_path", width=0, stretch=False)

        vscroll = ttk.Scrollbar(win, orient=tk.VERTICAL, command=results_tree.yview)
        hscroll = ttk.Scrollbar(win, orient=tk.HORIZONTAL, command=results_tree.xview)
        results_tree.configure(yscrollcommand=vscroll.set, xscrollcommand=hscroll.set)

        results_tree.pack(padx=8, pady=(8, 0), fill="both", expand=True)
        vscroll.pack(side=tk.RIGHT, fill="y")
        hscroll.pack(fill="x", padx=8, pady=(0, 8))

        btn_frame = tk.Frame(win, bg="#f7f7f7")
        btn_frame.pack(fill="x", padx=8, pady=(0, 8))
        tk.Button(btn_frame, text="Open Zip Folder", command=lambda: _open_selected_zip(results_tree)).pack(side=tk.LEFT)

        def on_double(event):
            _open_selected_zip(results_tree)

        results_tree.bind("<Double-1>", on_double)

        details_frame = tk.Frame(win, bg="#f7f7f7", bd=2, relief=tk.GROOVE)
        details_frame.pack(fill="x", padx=8, pady=(0, 8))

        detail_labels = {}

        def _open_map(loc_str: str):
            if not loc_str:
                return
            try:
                parts = [p.strip() for p in loc_str.split(",")]
                if len(parts) >= 2:
                    lat = float(parts[0])
                    lon = float(parts[1])
                    url = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
                    webbrowser.open(url)
                    return
            except Exception:
                pass
            try:
                query = loc_str.replace(" ", "+")
                url = f"https://www.google.com/maps/search/{query}"
                webbrowser.open(url)
            except Exception as e:
                messagebox.showerror("Error", f"Unable to open map: {e}")

        def _update_details(selected_item):
            for widget in details_frame.winfo_children():
                widget.destroy()
            if not selected_item:
                return
            item = results_tree.item(selected_item)
            values = item.get("values", [])
            fields = (
                "arcname", "zip_name", "original", "size", "mtime", "recorded", "location", "description", "zip_path"
            )
            data = {field: (values[i] if i < len(values) else "") for i, field in enumerate(fields)}

            if _is_image_file(data.get("arcname", "")):
                try:
                    with zipfile.ZipFile(data["zip_path"], 'r') as zf:
                        with zf.open(data["arcname"]) as f:
                            image_data = f.read()
                            image = Image.open(io.BytesIO(image_data))
                            image.thumbnail((200, 200))
                            photo = ImageTk.PhotoImage(image)
                            
                            image_label = tk.Label(details_frame, image=photo, bg="#f7f7f7")
                            image_label.image = photo # keep a reference!
                            image_label.pack(pady=5)
                except Exception:
                    pass

            for field, val in data.items():
                if not val:
                    continue

                if field == "description":
                    label = tk.Label(details_frame, text=f"Description: {val}", bg="#f7f7f7", anchor="w", wraplength=400, justify=tk.LEFT)
                    label.pack(fill="x", pady=5)
                elif field == "location":
                    row = tk.Frame(details_frame, bg="#f7f7f7")
                    row.pack(fill="x")
                    lbl = tk.Label(row, text=f"{field}: {val}", bg="#f7f7f7", anchor="w")
                    lbl.pack(side=tk.LEFT, fill="x", expand=True)
                    is_coords = False
                    try:
                        parts = [p.strip() for p in val.split(",")]
                        if len(parts) >= 2:
                            float(parts[0])
                            float(parts[1])
                            is_coords = True
                    except Exception:
                        is_coords = False
                    if is_coords:
                        btn = tk.Button(row, text="Open map", command=lambda v=val: _open_map(v))
                        btn.pack(side=tk.RIGHT)
                elif field not in ["zip_path", "original", "arcname", "description"]:
                    label = tk.Label(details_frame, text=f"{field}: {val}", bg="#f7f7f7", anchor="w")
                    label.pack(fill="x")

        def on_select(event):
            selected_item = results_tree.selection()
            _update_details(selected_item[0] if selected_item else None)

        results_tree.bind("<<TreeviewSelect>>", on_select)

    def _do_search(query: str, results_tree: ttk.Treeview):
        for i in results_tree.get_children():
            results_tree.delete(i)
        if not query:
            results_tree.insert("", "end", values=("Enter a search term.", "", "", "", "", "", "", "", ""))
            return
        rows = search_files(query)
        if not rows:
            results_tree.insert("", "end", values=("No matches found.", "", "", "", "", "", "", "", ""))
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat() if mtime else "N/A"
            zip_name = os.path.basename(zip_path_row) if zip_path_row else ""
            values = (
                arcname,
                zip_name,
                original_path,
                file_size or "",
                mtime_str,
                recorded_at,
                location or "",
                description or "",
                zip_path_row or "",
            )
            results_tree.insert("", "end", values=values)

    def _open_selected_zip(results_tree: ttk.Treeview):
        sel = results_tree.selection()
        if not sel:
            messagebox.showinfo("Info", "Select an entry first.")
            return
        item = sel[0]
        vals = results_tree.item(item, "values")
        zip_path_row = vals[8] if len(vals) > 8 else (vals[7] if len(vals) > 7 else None)
        if not zip_path_row:
            messagebox.showerror("Error", "Can't determine zip path for selection.")
            return
        folder = os.path.abspath(os.path.dirname(zip_path_row))
        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform.startswith("darwin"):
                subprocess.run(["open", folder])
            else:
                subprocess.run(["xdg-open", folder])
        except Exception as e:
            messagebox.showerror("Error", f"Cannot open folder: {e}")

    root.protocol("WM_DELETE_WINDOW", _on_close)

    # --- Jobs display ---
    jobs_frame = tk.Frame(root, bg="#f7f7f7", bd=2, relief=tk.GROOVE)
    jobs_frame.pack(padx=8, pady=8, fill="x")

    jobs_toolbar = tk.Frame(jobs_frame, bg="#f7f7f7")
    jobs_toolbar.pack(fill="x", padx=4, pady=4)
    tk.Label(jobs_toolbar, text="Jobs:", bg="#f7f7f7").pack(side=tk.LEFT)
    
    jobs_tree_frame = tk.Frame(jobs_frame)
    jobs_tree_frame.pack(fill="x", expand=True, padx=4, pady=(0,4))
    
    job_cols = ("name", "status", "schedule", "next_run_at", "last_run_status", "last_run_at", "source", "destination", "onedrive", "move_files")
    jobs_tree = ttk.Treeview(jobs_tree_frame, columns=job_cols, show="headings", height=5)
    jobs_tree.heading("name", text="Job Name")
    jobs_tree.heading("status", text="Status")
    jobs_tree.heading("schedule", text="Schedule")
    jobs_tree.heading("next_run_at", text="Next Run At")
    jobs_tree.heading("last_run_status", text="Last Run Status")
    jobs_tree.heading("last_run_at", text="Last Run At")
    jobs_tree.heading("source", text="Source Path")
    jobs_tree.heading("destination", text="Destination Path")
    jobs_tree.heading("onedrive", text="Upload to OneDrive")
    jobs_tree.heading("move_files", text="Move Files")
    
    jobs_tree.column("name", width=120, anchor="w")
    jobs_tree.column("status", width=80, anchor="w")
    jobs_tree.column("schedule", width=80, anchor="w")
    jobs_tree.column("next_run_at", width=140, anchor="w")
    jobs_tree.column("last_run_status", width=100, anchor="w")
    jobs_tree.column("last_run_at", width=140, anchor="w")
    jobs_tree.column("source", width=200, anchor="w")
    jobs_tree.column("destination", width=200, anchor="w")
    jobs_tree.column("onedrive", width=100, anchor="center")
    jobs_tree.column("move_files", width=100, anchor="center")
    
    jobs_vscroll = ttk.Scrollbar(jobs_tree_frame, orient=tk.VERTICAL, command=jobs_tree.yview)
    jobs_tree.configure(yscrollcommand=jobs_vscroll.set)
    jobs_vscroll.pack(side=tk.RIGHT, fill="y")
    jobs_tree.pack(fill="x", expand=True)

    def _refresh_jobs_list():
        for i in jobs_tree.get_children():
            jobs_tree.delete(i)
        jobs = list_jobs()
        for job in jobs:
            # Adjust tuple unpacking to include the new 'schedule_hour' field
            id, name, source, dest, upload, move_files, created, status, last_run, last_run_status, schedule, next_run_at, schedule_hour, schedule_minute, schedule_date = job
            upload_str = "Yes" if upload == 1 else "No"
            move_files_str = "Yes" if move_files == 1 else "No"

            # Format dates for display
            last_run_disp = datetime.fromisoformat(last_run).astimezone().strftime('%Y-%m-%d %H:%M:%S') if last_run else ""
            next_run_at_disp = datetime.fromisoformat(next_run_at).astimezone().strftime('%Y-%m-%d %H:%M:%S') if next_run_at else "N/A"

            values = (name, status or "Idle", schedule or "Manual", next_run_at_disp, last_run_status or "", last_run_disp, source, dest, upload_str, move_files_str)
            jobs_tree.insert("", "end", values=values, iid=str(id))

    def _open_add_job_window(job_to_edit=None):
        job_win = tk.Toplevel(root)
        job_win.title("Add Job" if job_to_edit is None else "Edit Job")
        job_win.geometry("600x350") # Increased height for schedule
        job_win.configure(bg="#f7f7f7")

        job_name_var = tk.StringVar()
        job_source_var = tk.StringVar()
        job_dest_name_var = tk.StringVar()
        job_onedrive_var = tk.BooleanVar()
        job_move_files_var = tk.BooleanVar()
        job_schedule_var = tk.StringVar(value="Manual")
        job_schedule_hour_var = tk.StringVar(value="0")
        job_schedule_minute_var = tk.StringVar(value="0")
        job_schedule_date_var = tk.StringVar(value="")

        # Fetch destinations
        destinations = list_destinations()
        dest_map = {name: loc for _, name, loc in destinations}
        dest_names = list(dest_map.keys())

        if job_to_edit:
            # Unpack all fields including the new schedule field
            job_id, name, source, dest_path, onedrive, move_files, _, _, _, _, schedule, _, schedule_hour, schedule_minute, schedule_date = job_to_edit
            job_name_var.set(name)
            job_source_var.set(source)
            job_onedrive_var.set(onedrive == 1)
            job_move_files_var.set(move_files == 1)
            job_schedule_var.set(schedule or "Manual")
            job_schedule_hour_var.set(str(schedule_hour or 0))
            job_schedule_minute_var.set(str(schedule_minute or 0))
            job_schedule_date_var.set(schedule_date or "")
            
            # Find the destination name from the path
            for dest_name, loc in dest_map.items():
                if os.path.abspath(loc) == os.path.abspath(dest_path):
                    job_dest_name_var.set(dest_name)
                    break

        tk.Label(job_win, text="Job Name:", bg="#f7f7f7").grid(row=0, column=0, padx=8, pady=8, sticky="w")
        tk.Entry(job_win, textvariable=job_name_var, width=50).grid(row=0, column=1, padx=8, pady=8, sticky="ew")

        tk.Label(job_win, text="Source Path:", bg="#f7f7f7").grid(row=1, column=0, padx=8, pady=8, sticky="w")
        source_frame = tk.Frame(job_win, bg="#f7f7f7")
        source_frame.grid(row=1, column=1, padx=8, pady=8, sticky="ew")
        tk.Entry(source_frame, textvariable=job_source_var, width=50).pack(side=tk.LEFT, fill="x", expand=True)
        tk.Button(source_frame, text="...", command=lambda: job_source_var.set(filedialog.askdirectory(title="Select Source Folder"))).pack(side=tk.LEFT, padx=(4,0))

        tk.Label(job_win, text="Schedule:", bg="#f7f7f7").grid(row=2, column=0, padx=8, pady=8, sticky="w")
        schedule_frame = tk.Frame(job_win, bg="#f7f7f7")
        schedule_frame.grid(row=2, column=1, padx=8, pady=8, sticky="w")
        schedule_combo = ttk.Combobox(schedule_frame, textvariable=job_schedule_var, values=["Manual", "Daily", "Hourly", "Once"], width=20)
        schedule_combo.pack(side=tk.LEFT)
        
        tk.Label(schedule_frame, text="Hour:", bg="#f7f7f7").pack(side=tk.LEFT, padx=(10, 0))
        hour_combo = ttk.Combobox(schedule_frame, textvariable=job_schedule_hour_var, values=list(range(24)), width=5)
        hour_combo.pack(side=tk.LEFT)

        tk.Label(schedule_frame, text="Minute:", bg="#f7f7f7").pack(side=tk.LEFT, padx=(10, 0))
        minute_combo = ttk.Combobox(schedule_frame, textvariable=job_schedule_minute_var, values=list(range(60)), width=5)
        minute_combo.pack(side=tk.LEFT)

        date_label = tk.Label(schedule_frame, text="Date (YYYY-MM-DD):", bg="#f7f7f7")
        date_entry = tk.Entry(schedule_frame, textvariable=job_schedule_date_var, width=12)

        def _toggle_date_entry(*args):
            if job_schedule_var.get() == "Once":
                date_label.pack(side=tk.LEFT, padx=(10, 0))
                date_entry.pack(side=tk.LEFT)
            else:
                date_label.pack_forget()
                date_entry.pack_forget()
        
        job_schedule_var.trace_add("write", _toggle_date_entry)
        _toggle_date_entry()


        tk.Label(job_win, text="Destination:", bg="#f7f7f7").grid(row=3, column=0, padx=8, pady=8, sticky="w")
        dest_combo = ttk.Combobox(job_win, textvariable=job_dest_name_var, values=dest_names, width=48)
        dest_combo.grid(row=3, column=1, padx=8, pady=8, sticky="ew")

        tk.Checkbutton(job_win, text="Upload to OneDrive", variable=job_onedrive_var, bg="#f7f7f7").grid(row=4, column=1, padx=8, pady=8, sticky="w")
        tk.Checkbutton(job_win, text="Move Files (deletes originals)", variable=job_move_files_var, bg="#f7f7f7").grid(row=5, column=1, padx=8, pady=8, sticky="w")
        
        job_win.grid_columnconfigure(1, weight=1)

        def _save_job():
            name = job_name_var.get().strip()
            source = job_source_var.get().strip()
            dest_name = job_dest_name_var.get().strip()
            schedule = job_schedule_var.get()
            schedule_hour = int(job_schedule_hour_var.get())
            schedule_minute = int(job_schedule_minute_var.get())
            schedule_date = job_schedule_date_var.get()

            if schedule == "Once" and not schedule_date:
                messagebox.showerror("Error", "Please enter a date for the 'Once' schedule.", parent=job_win)
                return
            
            if schedule_date:
                try:
                    datetime.strptime(schedule_date, "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror("Error", "Invalid date format. Please use YYYY-MM-DD.", parent=job_win)
                    return
            
            if not name or not source or not dest_name:
                messagebox.showerror("Error", "Job Name, Source, and Destination are required.", parent=job_win)
                return
            
            dest_path = dest_map.get(dest_name)
            if not dest_path:
                messagebox.showerror("Error", "Invalid destination selected.", parent=job_win)
                return

            if job_to_edit:
                # For simplicity, we delete and re-add. A real app might update in place.
                delete_job(job_to_edit[1])

            try:
                add_job(name, source, dest_path, job_onedrive_var.get(), job_move_files_var.get(), schedule, schedule_hour=schedule_hour, schedule_minute=schedule_minute, schedule_date=schedule_date)
                _refresh_jobs_list()
                job_win.destroy()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "A job with this name already exists.", parent=job_win)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save job: {e}", parent=job_win)

        tk.Button(job_win, text="Save Job", command=_save_job).grid(row=6, column=1, padx=8, pady=16, sticky="e")
        job_win.transient(root)
        job_win.grab_set()
        root.wait_window(job_win)

    def _delete_selected_job():
        selected_item = jobs_tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Select a job to delete.")
            return
        
        item_values = jobs_tree.item(selected_item[0], "values")
        job_name = item_values[0]
        
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete the job '{job_name}'?"):
            try:
                delete_job(job_name)
                _refresh_jobs_list()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete job: {e}")
    
    def _run_selected_job():
        selected_item = jobs_tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Select a job to run.")
            return
        
        job_id = int(selected_item[0])

        all_jobs = list_jobs()
        job_to_run = None
        for job in all_jobs:
            if job[0] == job_id:
                job_to_run = job
                break
        
        if not job_to_run:
            messagebox.showerror("Error", "Could not find the selected job details.")
            return

        job_id, name, source_path, dest_path, onedrive, move_files, _, status, last_run, last_run_status, schedule, next_run_at, schedule_hour, schedule_minute, schedule_date = job_to_run
        
        if not os.path.exists(source_path):
            messagebox.showerror("Error", f"Source path for job '{name}' does not exist:\n{source_path}")
            return
        
        status_var.set(f"Running job: {name}")
        upload = (onedrive == 1)
        move = (move_files == 1)
        t = threading.Thread(target=_run_zip_thread, args=(source_path, root, status_var, upload, dest_path, job_id, schedule, schedule_hour, schedule_minute, schedule_date, move))
        t.daemon = False
        with active_threads_lock:
            active_threads.add(t)
        t.start()


    tk.Button(jobs_toolbar, text="Add Job", command=_open_add_job_window).pack(side=tk.LEFT, padx=6)
    
    def _open_edit_job_window():
        selected_item = jobs_tree.selection()
        if not selected_item:
            messagebox.showinfo("Info", "Select a job to edit.")
            return
        
        job_id = int(selected_item[0])

        all_jobs = list_jobs()
        job_to_edit = None
        for job in all_jobs:
            if job[0] == job_id:
                job_to_edit = job
                break
        
        if job_to_edit:
            _open_add_job_window(job_to_edit=job_to_edit)
        else:
            messagebox.showerror("Error", "Could not find the selected job details.")

    tk.Button(jobs_toolbar, text="Edit Job", command=_open_edit_job_window).pack(side=tk.LEFT, padx=6)
    tk.Button(jobs_toolbar, text="Delete Job", command=_delete_selected_job).pack(side=tk.LEFT, padx=6)
    tk.Button(jobs_toolbar, text="Run Job", command=_run_selected_job, bg="#4CAF50", fg="white").pack(side=tk.LEFT, padx=6)
    tk.Button(jobs_toolbar, text="Create/Edit Destinations", command=_open_create_destination_window, bg="navy blue", fg="white").pack(side=tk.LEFT, padx=6)

    _refresh_jobs_list()

    # --- New DB files display ---
    db_files_frame = tk.Frame(root, bg="#f7f7f7", bd=2, relief=tk.GROOVE)
    db_files_frame.pack(padx=8, pady=8, fill="both", expand=True)

    search_bar_frame = tk.Frame(db_files_frame, bg="#f7f7f7")
    search_bar_frame.pack(fill="x", padx=4, pady=4)
    tk.Label(search_bar_frame, text="Search Files:", bg="#f7f7f7").pack(side=tk.LEFT)
    db_query_var = tk.StringVar()
    db_search_entry = tk.Entry(search_bar_frame, textvariable=db_query_var, width=50)
    db_search_entry.pack(side=tk.LEFT, padx=6, fill="x", expand=True)

    def _do_main_search(query: str, results_tree: ttk.Treeview):
        for i in results_tree.get_children():
            results_tree.delete(i)
        rows = search_files(query, limit=100) # Limit to 100 for the main view
        if not rows:
            results_tree.insert("", "end", values=("No matches found." if query else "No files in DB. Zip a file to start.", "", "", ""))
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            zip_name = os.path.basename(zip_path_row) if zip_path_row else ""
            values = (
                arcname,
                zip_name,
                recorded_at,
                original_path,
            )
            results_tree.insert("", "end", values=values)

    tk.Button(search_bar_frame, text="Search", command=lambda: _do_main_search(db_query_var.get(), db_results_tree)).pack(side=tk.LEFT, padx=6)
    tk.Button(search_bar_frame, text="Refresh", command=lambda: _do_main_search("", db_results_tree)).pack(side=tk.LEFT)
    tk.Button(search_bar_frame, text="Advanced Search", command=_open_search_window).pack(side=tk.LEFT, padx=6)

    tree_frame = tk.Frame(db_files_frame)
    tree_frame.pack(fill="both", expand=True, padx=4, pady=(0,4))

    db_cols = ("arcname", "zip_name", "recorded", "original")
    db_results_tree = ttk.Treeview(tree_frame, columns=db_cols, show="headings")
    db_results_tree.heading("arcname", text="Name")
    db_results_tree.heading("zip_name", text="Archive")
    db_results_tree.heading("recorded", text="Date Added")
    db_results_tree.heading("original", text="Original Path")

    db_results_tree.column("arcname", width=200, anchor="w")
    db_results_tree.column("zip_name", width=150, anchor="w")
    db_results_tree.column("recorded", width=150, anchor="w")
    db_results_tree.column("original", width=300, anchor="w")

    vscroll = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=db_results_tree.yview)
    hscroll = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL, command=db_results_tree.xview)
    db_results_tree.configure(yscrollcommand=vscroll.set, xscrollcommand=hscroll.set)

    vscroll.pack(side=tk.RIGHT, fill="y")
    hscroll.pack(side=tk.BOTTOM, fill="x")
    db_results_tree.pack(fill="both", expand=True)


    # Load initial data
    _do_main_search("", db_results_tree)

    def on_db_tree_double_click(event):
        sel = db_results_tree.selection()
        if not sel:
            return
        # The full details are not in this simple view.
        # So we can either open the advanced search, or just open the zip location
        # For now, let's just show a message. A better implementation would
        # fetch full details and show them.
        messagebox.showinfo("Info", "Use 'Search DB (Advanced)' for more details and actions.")

    db_results_tree.bind("<Double-1>", on_db_tree_double_click)


    tk.Label(root, textvariable=status_var, bg="#f7f7f7", fg="#333").pack(side=tk.BOTTOM, pady=10)

    tk.Button(root, text="Exit", command=_on_close).pack(side=tk.BOTTOM, pady=5)

    # Start the scheduler
    _run_scheduler(root, status_var, active_threads, active_threads_lock)

    root.mainloop()


# ---------- CLI ----------
def run_cli():
    import argparse

    parser = argparse.ArgumentParser(description="FileZipper CLI")
    parser.add_argument("target", nargs="?", help="File or folder to compress")
    parser.add_argument("--search", "-s", help="Search the DB for a filename substring", default=None)
    parser.add_argument("--onedrive", action="store_true", help="Upload resulting archive to OneDrive (requires MSAL_CLIENT_ID env var)")
    parser.add_argument("--dest", "-d", help="Destination folder to place the zip (defaults to ./Zipped)", default=None)
    parser.add_argument(
        "--on-conflict",
        choices=["overwrite", "rename", "cancel"],
        help="Action to take if the zip file already exists (overwrite, rename, or cancel). Only for CLI.",
        default=None,
    )
    args = parser.parse_args()
    if args.search:
        rows = search_files(args.search, limit=500)
        if not rows:
            print("No matches found.")
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat() if mtime else "N/A"
            loc_str = f" | location: {location}" if location else ""
            desc_str = f" | description: {description}" if description else ""
            print(f"{arcname} | in: {zip_path_row} | original: {original_path} | size: {file_size} | mtime: {mtime_str} | recorded: {recorded_at}{loc_str}{desc_str}")
        return

    target = args.target or input("Enter path to folder/file: ").strip()
    if not os.path.exists(target):
        print("Invalid path.")
        return
    action, zip_dest = zip_path(target, args.dest, on_conflict_action=args.on_conflict)
    if zip_dest is None:
        print("Operation cancelled by user.")
        return
    print(f"DEBUG: run_cli received action: {action}")

    if action == "created":
        print(f"Archive created: {zip_dest}")
    elif action == "overwritten":
        print(f"Archive overwritten: {zip_dest}")
    elif action == "renamed":
        print(f"Archive renamed: {zip_dest}")

    if args.onedrive:
        try:
            token = acquire_onedrive_token()
            remote = f"Zipped/{os.path.basename(zip_dest)}"
            resp = upload_file_to_onedrive(zip_dest, remote, token)
            print(f"Uploaded to OneDrive at: {resp.get('webUrl') or remote}")
        except Exception as e:
            print(f"OneDrive upload failed: {e}")


# ---------- Entrypoint ----------
def main():
    # Start the MCP HTTP server on a background thread
    start_mcp_server()

    # Drag-and-drop support: if paths supplied on command line, compress them and exit
    if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument("target")
        parser.add_argument("--on-conflict", choices=["overwrite", "rename", "cancel"], default=None)
        args, unknown = parser.parse_known_args()
        
        for path in [args.target] + unknown:
            if os.path.exists(path):
                try:
                    action, zip_dest = zip_path(path, on_conflict_action=args.on_conflict)
                    if action == "cancelled":
                        print("Operation cancelled by user.")
                    else:
                        if action == "created":
                            print(f"Archive created: {zip_dest}")
                        elif action == "overwritten":
                            print(f"Archive overwritten: {zip_dest}")
                        elif action == "renamed":
                            print(f"Archive renamed: {zip_dest}")
                except Exception as e:
                    print(f"Error compressing {path}: {e}")
        return

    try:
        if tk is None:
            raise RuntimeError("GUI not available")
        run_gui()
    except Exception:
        run_cli()


if __name__ == "__main__":
    main()
