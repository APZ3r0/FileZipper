
import os
import sqlite3
import zipfile
import io
import argparse
from PIL import Image
from transformers import BlipProcessor, BlipForConditionalGeneration
import torch

# --- Database and Configuration ---
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "filezipper_records.db")

# Load model and processor once globally
# Use try-except for robust handling in case of download issues or GPU availability
try:
    print("Loading image captioning model (Salesforce/blip-image-captioning-base)... This may take a moment.")
    processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
    model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
    # Move model to GPU if available
    if torch.cuda.is_available():
        model.to("cuda")
        print("Model moved to GPU.")
    else:
        print("GPU not available, model running on CPU.")
except Exception as e:
    print(f"Error loading local image captioning model: {e}")
    processor = None
    model = None


def _is_image_file(path: str) -> bool:
    """Return True if path has an image file extension."""
    if not path:
        return False
    lower = path.lower()
    return any(lower.endswith(ext) for ext in (".jpg", ".jpeg"))


def generate_local_image_description(image_data: bytes) -> str | None:
    """
    Generates an image caption using a local Hugging Face model.
    """
    if processor is None or model is None:
        print("  - Local image captioning model not loaded, cannot generate description.")
        return None
    try:
        img = Image.open(io.BytesIO(image_data)).convert("RGB")
        inputs = processor(images=img, return_tensors="pt")
        if torch.cuda.is_available():
            inputs = {k: v.to("cuda") for k, v in inputs.items()}
        out = model.generate(**inputs, max_new_tokens=20) # Limit generation length
        caption = processor.decode(out[0], skip_special_tokens=True)
        if caption and caption.strip():
            return caption.strip()
    except Exception as e:
        print(f"  - Error generating local description: {e}")
    return None


def generate_image_description_from_zip(zip_path: str, arcname: str) -> str | None:
    """
    Extracts an image from a zip file and generates a description using the local model.
    """
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            if arcname not in zf.namelist():
                print(f"  - Arcname '{arcname}' not found in zip '{zip_path}'.")
                return None

            with zf.open(arcname) as f:
                image_data = f.read()
                return generate_local_image_description(image_data)

    except FileNotFoundError:
        print(f"  - Zip file not found: {zip_path}")
        return None
    except zipfile.BadZipFile:
        print(f"  - '{zip_path}' is not a valid zip file.")
        return None
    except Exception as e:
        print(f"  - An unexpected error occurred: {e}")
        return None


def main():
    """
    Main function to find images without descriptions, generate them, and update the DB.
    """
    parser = argparse.ArgumentParser(description="Generate descriptions for images in the FileZippr database.")
    # No --token needed for local model, but keep for compatibility if user explicitly provides it
    parser.add_argument("--token", help="Hugging Face API Token (not used for local model, but kept for compatibility).")
    args = parser.parse_args()

    if processor is None or model is None:
        print("Local model could not be loaded. Please check your transformers and torch installation.")
        return

    if not os.path.exists(DB_PATH):
        print(f"Database not found at '{DB_PATH}'.")
        return

    try:
        conn = sqlite3.connect(DB_PATH, timeout=30)
        cursor = conn.cursor()

        # Find all image files (jpg, jpeg) that have no description
        cursor.execute("""
            SELECT id, original_path, arcname, zip_path
            FROM zipped_files
            WHERE (description IS NULL OR description = '')
              AND (LOWER(arcname) LIKE '%.jpg' OR LOWER(arcname) LIKE '%.jpeg')
        """)
        files_to_process = cursor.fetchall()

        if not files_to_process:
            print("No .jpg/.jpeg files found in the database that need a description.")
            return

        print(f"Found {len(files_to_process)} image(s) to process.")

        for file_id, original_path, arcname, zip_path in files_to_process:
            print(f"\nProcessing '{arcname}' from archive '{os.path.basename(zip_path)}'...")

            # Generate the description using the content from the zip file
            description = generate_image_description_from_zip(zip_path, arcname)

            if description:
                try:
                    cursor.execute(
                        "UPDATE zipped_files SET description = ? WHERE id = ?",
                        (description, file_id)
                    )
                    conn.commit()
                    print(f"  + Success! Description: '{description}'")
                except Exception as e:
                    conn.rollback()
                    print(f"  - DB Error: Failed to update description for file ID {file_id}: {e}")
            else:
                print("  - Failed to generate a description.")

    except sqlite3.Error as e:
        print(f"A database error occurred: {e}")
    finally:
        if 'conn' in locals() and conn:
            conn.close()

if __name__ == "__main__":
    main()
