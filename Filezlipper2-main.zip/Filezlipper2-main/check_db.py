import sqlite3

conn = sqlite3.connect('filezipper_records.db')

# Count records with location data
cur = conn.execute("SELECT COUNT(*) FROM zipped_files WHERE location IS NOT NULL AND location != ''")
location_count = cur.fetchone()[0]

# Count total records
cur = conn.execute('SELECT COUNT(*) FROM zipped_files')
total_count = cur.fetchone()[0]

# Get sample records with location
cur = conn.execute("SELECT arcname, location FROM zipped_files WHERE location IS NOT NULL AND location != '' LIMIT 5")
samples = cur.fetchall()

# Get sample records without location (image files)
cur = conn.execute("SELECT arcname, location FROM zipped_files WHERE (arcname LIKE '%.jpg' OR arcname LIKE '%.jpeg' OR arcname LIKE '%.png') LIMIT 5")
image_samples = cur.fetchall()

print(f"Records with location data: {location_count}")
print(f"Total records: {total_count}")
print(f"\nSample records with location:")
for name, loc in samples:
    print(f"  {name}: {loc}")

print(f"\nSample image files:")
for name, loc in image_samples:
    print(f"  {name}: {loc if loc else '(no location)'}")

conn.close()
