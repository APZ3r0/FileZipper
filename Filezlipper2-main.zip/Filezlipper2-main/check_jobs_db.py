import sqlite3
from datetime import datetime

def check_jobs():
    """Reads and prints all jobs from the database."""
    try:
        conn = sqlite3.connect('filezipper_records.db')
        cur = conn.execute("SELECT id, name, schedule, next_run_at, last_run_at, last_run_status, status FROM jobs ORDER BY name")
        rows = cur.fetchall()
        
        print("--- Jobs in Database ---")
        for row in rows:
            job_id, name, schedule, next_run_at, last_run_at, last_run_status, status = row
            
            # Format for readability
            next_run_str = "N/A"
            if next_run_at:
                try:
                    # Assumes stored as UTC ISO format
                    utc_dt = datetime.fromisoformat(next_run_at)
                    local_dt = utc_dt.astimezone()
                    next_run_str = local_dt.strftime('%Y-%m-%d %H:%M:%S %Z')
                except (ValueError, TypeError):
                    next_run_str = f"Invalid format: {next_run_at}"

            last_run_str = "N/A"
            if last_run_at:
                try:
                    utc_dt = datetime.fromisoformat(last_run_at)
                    local_dt = utc_dt.astimezone()
                    last_run_str = local_dt.strftime('%Y-%m-%d %H:%M:%S %Z')
                except (ValueError, TypeError):
                    last_run_str = f"Invalid format: {last_run_at}"

            print(
                f"  ID: {job_id}\n"
                f"  Name: {name}\n"
                f"  Status: {status or 'N/A'}\n"
                f"  Schedule: {schedule}\n"
                f"  Next Run At (Local): {next_run_str}\n"
                f"  Last Run At (Local): {last_run_str}\n"
                f"  Last Run Status: {last_run_status or 'N/A'}\n"
                f"  --------------------"
            )

    except sqlite3.Error as e:
        print(f"Database error: {e}")
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    check_jobs()
