import os
import zipfile
import subprocess
import sys
import threading
import sqlite3
from datetime import datetime, timezone

import database
from destinations_ui import open_destinations_window
from job_runner import run_job_in_thread, zip_path, ConflictResolution # Import ConflictResolution

import sched
import http.server
import socketserver
import json
import webbrowser
from urllib.parse import urlparse, parse_qs
import time
from datetime import datetime, timezone, timedelta
import io

# endregion

import argparse

# region Optional Imports
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from PIL import Image, ImageTk
    from tkcalendar import Calendar
except ImportError:
    tk = None
    Calendar = None

try:
    import msal
    import requests
except ImportError:
    msal = None
# endregion

# This script provides a graphical and command-line interface for compressing files and folders into ZIP archives.
# It records metadata about each compressed file—such as its original path, size, and modification time—into an
# SQLite database. The script also includes functionality for searching the database, managing compression jobs,
# and optionally uploading archives to Microsoft OneDrive. It is designed to be self-contained, handling
# dependencies gracefully and defaulting to a CLI if GUI libraries are unavailable.
#
# Features:
# - GUI and CLI interfaces for file and folder compression.
# - SQLite database for tracking file metadata and compression jobs.
# - Search functionality to locate files within archives.
# - Job management for automating recurring compression tasks.
# - Optional integration with Microsoft OneDrive for cloud uploads.
# - Automatic extraction of location data from image files (if available).
# - Graceful fallback to CLI mode if GUI components are not installed.


# Optional libs for OneDrive (MS Graph)
try:
    import msal
except Exception:
    msal = None

try:

    import requests
except Exception:
    requests = None

# Robust workaround for older pydevd / debugpy sys_monitoring (pydevd 3.14.0)
try:
    if not hasattr(threading.Thread, "_handle"):
        threading.Thread._handle = None
    mt = threading.main_thread()
    if not hasattr(mt, "_handle"):
        mt._handle = None
except Exception:
    pass

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
except Exception:
    tk = None  # GUI won't be available in headless environments

# Database (records each file added to archives)
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "filezipper_records.db")








# ---------- Model Context Protocol (MCP) over HTTP Server ----------
MCP_PORT = 8999

class MCPRequestHandler(http.server.BaseHTTPRequestHandler):
    """Handles HTTP requests for the Model Context Protocol."""

    def do_GET(self):
        """Handle GET requests to expose application data model."""
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        query_params = parse_qs(parsed_path.query)

        try:
            if path == '/files':
                search_query = query_params.get('search', [''])[0]
                data = database.search_files(search_query)
                self.send_json_response(data)
            elif path == '/jobs':
                data = database.list_jobs()
                self.send_json_response(data)
            elif path == '/destinations':
                data = database.list_destinations()
                self.send_json_response(data)
            else:
                self.send_error(404, "Not Found")
        except Exception as e:
            self.send_error(500, f"Internal Server Error: {e}")

    def send_json_response(self, data, status_code=200):
        """Sends a JSON response."""
        self.send_response(status_code)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        # Use a custom default to handle non-serializable types like datetime
        json_str = json.dumps(data, indent=2, default=str).encode('utf-8')
        self.wfile.write(json_str)

    def log_message(self, format, *args):
        """Suppress HTTP server logging to keep the console clean."""
        return

def start_mcp_server(port=MCP_PORT):
    """Starts the MCP HTTP server in a separate thread."""
    def run_server():
        with socketserver.TCPServer(("", port), MCPRequestHandler) as httpd:
            # This print is useful for confirming the server started.
            print(f"MCP server running on http://localhost:{port}")
            httpd.serve_forever()

    server_thread = threading.Thread(target=run_server)
    server_thread.daemon = True  # Allows main program to exit even if thread is running
    server_thread.start()





# ---------- GUI ----------
def run_gui():
    if tk is None:
        raise RuntimeError("Tkinter is not available in this environment.")

    root = tk.Tk()
    root.title("FileZipper")
    root.geometry("800x700") # Increased height
    root.configure(bg="#e6ffe6")

    source_var = tk.StringVar()
    status_var = tk.StringVar(value="Ready.")
    onedrive_var = tk.BooleanVar(value=False)
    dest_var = tk.StringVar(value=os.path.join(BASE_DIR, "Zipped"))

    active_threads = set()
    active_threads_lock = threading.Lock()
    shutting_down = False

    def browse_folder():
        path = filedialog.askdirectory(title="Select Folder to Zip")
        if path:
            source_var.set(path)

    def browse_destination():
        path = filedialog.askdirectory(title="Select Destination Folder for Zip")
        if path:
            dest_var.set(path)

    def compress():
        nonlocal shutting_down
        if shutting_down:
            return
        path = source_var.get().strip()
        if not path or not os.path.exists(path):
            messagebox.showerror("Error", "Please select a valid folder or file.")
            return

        status_var.set("Compressing.")
        
        # Create a dummy job tuple for direct compression calls
        dummy_job = (
            None,  # job_id
            f"Direct Compress: {os.path.basename(path)}",  # name
            path,  # path
            dest_var.get(),  # output_root
            onedrive_var.get(),  # upload_to_onedrive
            False,  # move_files (default to False for direct compress unless a UI option is added)
            None, None, None, None,  # created, status, last_run, last_run_status (unused for direct)
            "Manual", # schedule
            None, # next_run_at (unused for direct)
            0, # schedule_hour
            0, # schedule_minute
            None, # schedule_date
            None,  # schedule_day_of_week
            False, # send_email_on_completion
            None # recipient_email
        )
        
        stop_event = threading.Event()
        # The on_conflict parameter is passed as RENAME for direct compression by default.
        t = threading.Thread(target=run_job_in_thread, args=(dummy_job, stop_event, ConflictResolution.RENAME, root, status_var, dest_var))
        t.daemon = False
        with active_threads_lock:
            active_threads.add(t)
        t.start()





    def _on_close():
        nonlocal shutting_down
        shutting_down = True
        try:
            for child in root.winfo_children():
                try:
                    child.configure(state="disabled")
                except Exception:
                    pass
        except Exception:
            pass
        with active_threads_lock:
            threads = list(active_threads)
        for t in threads:
            try:
                t.join(timeout=5.0)
            except Exception:
                pass
        try:
            root.destroy()
        except Exception:
            pass

def _is_image_file(filename: str) -> bool:
    """Check if a filename has an image extension."""
    if not filename:
        return False
    return filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff'))


def open_search_window(root_widget):
    win = tk.Toplevel(root_widget)
    win.title("Search zipped files")
    win.geometry("1000x480")
    win.configure(bg="#f7f7f7")

    tk.Label(win, text="Search term (filename or path substring):", bg="#f7f7f7").pack(anchor="w", padx=8, pady=(8, 0))
    query_var = tk.StringVar()
    qframe = tk.Frame(win, bg="#f7f7f7")
    qframe.pack(fill="x", padx=8)
    tk.Entry(qframe, textvariable=query_var, width=64).pack(side=tk.LEFT, padx=(0, 6))
    tk.Button(qframe, text="Search", command=lambda: _do_search(query_var.get(), results_tree)).pack(side=tk.LEFT)

    columns = ("arcname", "zip_name", "original", "size", "mtime", "recorded", "location", "description", "zip_path")
    results_tree = ttk.Treeview(win, columns=columns, show="headings")
    results_tree.heading("arcname", text="Name")
    results_tree.heading("zip_name", text="Archive")
    results_tree.heading("original", text="Original Path")
    results_tree.heading("size", text="Size")
    results_tree.heading("mtime", text="Modified")
    results_tree.heading("recorded", text="Recorded")
    results_tree.heading("location", text="Location")
    results_tree.heading("description", text="Description")
    results_tree.heading("zip_path", text="zip_path")

    results_tree.column("arcname", width=200, anchor="w")
    results_tree.column("zip_name", width=160, anchor="w")
    results_tree.column("original", width=320, anchor="w")
    results_tree.column("size", width=80, anchor="center")
    results_tree.column("mtime", width=140, anchor="center")
    results_tree.column("recorded", width=180, anchor="center")
    results_tree.column("location", width=200, anchor="w")
    results_tree.column("description", width=300, anchor="w")
    results_tree.column("zip_path", width=0, stretch=False)

    vscroll = ttk.Scrollbar(win, orient=tk.VERTICAL, command=results_tree.yview)
    hscroll = ttk.Scrollbar(win, orient=tk.HORIZONTAL, command=results_tree.xview)
    results_tree.configure(yscrollcommand=vscroll.set, xscrollcommand=hscroll.set)

    results_tree.pack(padx=8, pady=(8, 0), fill="both", expand=True)
    vscroll.pack(side=tk.RIGHT, fill="y")
    hscroll.pack(fill="x", padx=8, pady=(0, 8))

    btn_frame = tk.Frame(win, bg="#f7f7f7")
    btn_frame.pack(fill="x", padx=8, pady=(0, 8))
    tk.Button(btn_frame, text="Open Zip Folder", command=lambda: _open_selected_zip(results_tree)).pack(side=tk.LEFT)

    def on_double(event):
        _open_selected_zip(results_tree)

    results_tree.bind("<Double-1>", on_double)

    details_frame = tk.Frame(win, bg="#f7f7f7", bd=2, relief=tk.GROOVE)
    details_frame.pack(fill="x", padx=8, pady=(0, 8))

    detail_labels = {}

    def _open_map(loc_str: str):
        if not loc_str:
            return
        try:
            parts = [p.strip() for p in loc_str.split(",")]
            if len(parts) >= 2:
                lat = float(parts[0])
                lon = float(parts[1])
                url = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
                webbrowser.open(url)
                return
        except Exception:
            pass
        try:
            query = loc_str.replace(" ", "+")
            url = f"https://www.google.com/maps/search/{query}"
            webbrowser.open(url)
        except Exception as e:
            messagebox.showerror("Error", f"Unable to open map: {e}")

    def _update_details(selected_item):
        for widget in details_frame.winfo_children():
            widget.destroy()
        if not selected_item:
            return
        item = results_tree.item(selected_item)
        values = item.get("values", [])
        fields = (
            "arcname", "zip_name", "original", "size", "mtime", "recorded", "location", "description", "zip_path"
        )
        data = {field: (values[i] if i < len(values) else "") for i, field in enumerate(fields)}

        if _is_image_file(data.get("arcname", "")):
            try:
                with zipfile.ZipFile(data["zip_path"], 'r') as zf:
                    with zf.open(data["arcname"]) as f:
                        image_data = f.read()
                        image = Image.open(io.BytesIO(image_data))
                        image.thumbnail((200, 200))
                        photo = ImageTk.PhotoImage(image)
                        
                        image_label = tk.Label(details_frame, image=photo, bg="#f7f7f7")
                        image_label.image = photo # keep a reference!
                        image_label.pack(pady=5)
            except Exception:
                pass

        for field, val in data.items():
            if not val:
                continue

            if field == "description":
                label = tk.Label(details_frame, text=f"Description: {val}", bg="#f7f7f7", anchor="w", wraplength=400, justify=tk.LEFT)
                label.pack(fill="x", pady=5)
            elif field == "location":
                row = tk.Frame(details_frame, bg="#f7f7f7")
                row.pack(fill="x")
                lbl = tk.Label(row, text=f"{field}: {val}", bg="#f7f7f7", anchor="w")
                lbl.pack(side=tk.LEFT, fill="x", expand=True)
                is_coords = False
                try:
                    parts = [p.strip() for p in val.split(",")]
                    if len(parts) >= 2:
                        float(parts[0])
                        float(parts[1])
                        is_coords = True
                except Exception:
                    is_coords = False
                if is_coords:
                    btn = tk.Button(row, text="Open map", command=lambda v=val: _open_map(v))
                    btn.pack(side=tk.RIGHT)
            elif field not in ["zip_path", "original", "arcname", "description"]:
                label = tk.Label(details_frame, text=f"{field}: {val}", bg="#f7f7f7", anchor="w")
                label.pack(fill="x")

    def on_select(event):
        selected_item = results_tree.selection()
        _update_details(selected_item[0] if selected_item else None)

    results_tree.bind("<<TreeviewSelect>>", on_select)

    def _do_search(query: str, results_tree: ttk.Treeview):
        for i in results_tree.get_children():
            results_tree.delete(i)
        if not query:
            results_tree.insert("", "end", values=("Enter a search term.", "", "", "", "", "", "", "", ""))
            return
        rows = database.search_files(query)
        if not rows:
            results_tree.insert("", "end", values=("No matches found.", "", "", "", "", "", "", "", ""))
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat() if mtime else "N/A"
            zip_name = os.path.basename(zip_path_row) if zip_path_row else ""
            values = (
                arcname,
                zip_name,
                original_path,
                file_size or "",
                mtime_str,
                recorded_at,
                location or "",
                description or "",
                zip_path_row or "",
            )
            results_tree.insert("", "end", values=values)

    def _open_selected_zip(results_tree: ttk.Treeview):
        sel = results_tree.selection()
        if not sel:
            messagebox.showinfo("Info", "Select an entry first.")
            return
        item = sel[0]
        vals = results_tree.item(item, "values")
        zip_path_row = vals[8] if len(vals) > 8 else (vals[7] if len(vals) > 7 else None)
        if not zip_path_row:
            messagebox.showerror("Error", "Can't determine zip path for selection.")
            return
        folder = os.path.abspath(os.path.dirname(zip_path_row))
        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform.startswith("darwin"):
                subprocess.run(["open", folder])
            else:
                subprocess.run(["xdg-open", folder])
        except Exception as e:
            messagebox.showerror("Error", f"Cannot open folder: {e}")

    win.protocol("WM_DELETE_WINDOW", win.destroy)

    # --- New DB files display ---
    db_files_frame = tk.Frame(win, bg="#f7f7f7", bd=2, relief=tk.GROOVE)
    db_files_frame.pack(padx=8, pady=8, fill="both", expand=True)

    search_bar_frame = tk.Frame(db_files_frame, bg="#f7f7f7")
    search_bar_frame.pack(fill="x", padx=4, pady=4)
    tk.Label(search_bar_frame, text="Search Files:", bg="#f7f7f7").pack(side=tk.LEFT)
    db_query_var = tk.StringVar()
    db_search_entry = tk.Entry(search_bar_frame, textvariable=db_query_var, width=50)
    db_search_entry.pack(side=tk.LEFT, padx=6, fill="x", expand=True)

    def _do_main_search(query: str, results_tree: ttk.Treeview):
        for i in results_tree.get_children():
            results_tree.delete(i)
        rows = database.search_files(query, limit=100) # Limit to 100 for the main view
        if not rows:
            results_tree.insert("", "end", values=("No matches found." if query else "No files in DB. Zip a file to start.", "", "", ""))
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            zip_name = os.path.basename(zip_path_row) if zip_path_row else ""
            values = (
                arcname,
                zip_name,
                recorded_at,
                original_path,
            )
            results_tree.insert("", "end", values=values)

    tk.Button(search_bar_frame, text="Search", command=lambda: _do_main_search(db_query_var.get(), db_results_tree)).pack(side=tk.LEFT, padx=6)
    tk.Button(search_bar_frame, text="Refresh", command=lambda: _do_main_search("", db_results_tree)).pack(side=tk.LEFT)
    tk.Button(search_bar_frame, text="Advanced Search", command=_open_search_window).pack(side=tk.LEFT, padx=6)

    tree_frame = tk.Frame(db_files_frame)
    tree_frame.pack(fill="both", expand=True, padx=4, pady=(0,4))

    db_cols = ("arcname", "zip_name", "recorded", "original")
    db_results_tree = ttk.Treeview(tree_frame, columns=db_cols, show="headings")
    db_results_tree.heading("arcname", text="Name")
    db_results_tree.heading("zip_name", text="Archive")
    db_results_tree.heading("recorded", text="Date Added")
    db_results_tree.heading("original", text="Original Path")

    db_results_tree.column("arcname", width=200, anchor="w")
    db_results_tree.column("zip_name", width=150, anchor="w")
    db_results_tree.column("recorded", width=150, anchor="w")
    db_results_tree.column("original", width=300, anchor="w")

    vscroll = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=db_results_tree.yview)
    hscroll = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL, command=db_results_tree.xview)
    db_results_tree.configure(yscrollcommand=vscroll.set, xscrollcommand=hscroll.set)

    vscroll.pack(side=tk.RIGHT, fill="y")
    hscroll.pack(side=tk.BOTTOM, fill="x")
    db_results_tree.pack(fill="both", expand=True)


    # Load initial data
    _do_main_search("", db_results_tree)

    def on_db_tree_double_click(event):
        sel = db_results_tree.selection()
        if not sel:
            return
        # The full details are not in this simple view.
        # So we can either open the advanced search, or just open the zip location
        # For now, let's just show a message. A better implementation would
        # fetch full details and show them.
        messagebox.showinfo("Info", "Use 'Search DB (Advanced)' for more details and actions.")

    db_results_tree.bind("<Double-1>", on_db_tree_double_click)


    tk.Label(root, textvariable=status_var, bg="#f7f7f7", fg="#333").pack(side=tk.BOTTOM, pady=10)

    tk.Button(root, text="Exit", command=_on_close).pack(side=tk.BOTTOM, pady=5)

    root.mainloop()


# ---------- CLI ----------
def run_cli():
    import argparse

    parser = argparse.ArgumentParser(description="FileZipper CLI")
    parser.add_argument("target", nargs="?", help="File or folder to compress")
    parser.add_argument("--search", "-s", help="Search the DB for a filename substring", default=None)
    parser.add_argument("--onedrive", action="store_true", help="Upload resulting archive to OneDrive (requires MSAL_CLIENT_ID env var)")
    parser.add_argument("--dest", "-d", help="Destination folder to place the zip (defaults to ./Zipped)", default=None)
    parser.add_argument(
        "--on-conflict",
        choices=["overwrite", "rename", "cancel"],
        help="Action to take if the zip file already exists (overwrite, rename, or cancel). Only for CLI.",
        default=None,
    )
    parser.add_argument("--job", help="Get job details from the database", default=None)
    parser.add_argument("--run-job", help="Run a job from the database", default=None)
    args = parser.parse_args()

    if args.job:
        job = database.get_job_by_name(args.job)
        if job:
            print(f"Job details: {job}")
        else:
            print(f"Job '{args.job}' not found.")
        return

    if args.run_job:
        job = database.get_job_by_name(args.run_job)
        if job:
            job_id, name, source_path, dest_path, onedrive, move_files, created_at, status, last_run_at, last_run_status, schedule, next_run_at, schedule_hour, schedule_minute, schedule_date = job
            action, zip_dest = zip_path(source_path, dest_path, on_conflict_action=args.on_conflict)
            if zip_dest:
                if onedrive:
                    try:
                        token = acquire_onedrive_token()
                        remote = f"Zipped/{os.path.basename(zip_dest)}"
                        resp = upload_file_to_onedrive(zip_dest, remote, token)
                        print(f"Uploaded to OneDrive at: {resp.get('webUrl') or remote}")
                    except Exception as e:
                        print(f"OneDrive upload failed: {e}")
                print(f"Job '{name}' run successfully.")
        else:
            print(f"Job '{args.run_job}' not found.")
        return

    if args.search:
        rows = database.search_files(args.search, limit=500)
        if not rows:
            print("No matches found.")
            return
        for r in rows:
            original_path, arcname, zip_path_row, file_size, mtime, compressed_size, location, description, recorded_at = r
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat() if mtime else "N/A"
            loc_str = f" | location: {location}" if location else ""
            desc_str = f" | description: {description}" if description else ""
            print(f"{arcname} | in: {zip_path_row} | original: {original_path} | size: {file_size} | mtime: {mtime_str} | recorded: {recorded_at}{loc_str}{desc_str}")
        return

    target = args.target or input("Enter path to folder/file: ").strip()
    if not os.path.exists(target):
        print("Invalid path.")
        return
    action, zip_dest = zip_path(target, args.dest, on_conflict_action=args.on_conflict)
    if zip_dest is None:
        print("Operation cancelled by user.")
        return
    print(f"DEBUG: run_cli received action: {action}")

    if action == "created":
        print(f"Archive created: {zip_dest}")
    elif action == "overwritten":
        print(f"Archive overwritten: {zip_dest}")
    elif action == "renamed":
        print(f"Archive renamed: {zip_dest}")

    if args.onedrive:
        try:
            token = acquire_onedrive_token()
            remote = f"Zipped/{os.path.basename(zip_dest)}"
            resp = upload_file_to_onedrive(zip_dest, remote, token)
            print(f"Uploaded to OneDrive at: {resp.get('webUrl') or remote}")
        except Exception as e:
            print(f"OneDrive upload failed: {e}")


# ---------- Entrypoint ----------
def main():
    """Main entry point for the FileMover GUI."""
    start_mcp_server()
    run_gui()