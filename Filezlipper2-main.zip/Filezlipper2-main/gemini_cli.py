import google.generativeai as genai
import os

# CONFIGURATION
# Best practice: Set this as an environment variable (export GOOGLE_API_KEY='...')
# For now, you can paste it directly below if testing locally.
API_KEY = os.getenv('GOOGLE_API_KEY') or 'AIzaSyDmOYifyovJG4WESI-9u8K7UiSZYWikfTk'

def start_chat():
    if API_KEY == 'YOUR_API_KEY_HERE':
        print("Error: Please put your API Key in the script or environment variables.")
        return

    genai.configure(api_key=API_KEY)
    
    # Initialize the model
    model = genai.GenerativeModel('gemini-1.5-flash')
    chat = model.start_chat(history=[])

    print("--- Gemini CLI Started (Type 'quit' to exit) ---")

    while True:
        try:
            user_input = input("\nYou: ")
            if user_input.lower() in ['quit', 'exit']:
                print("Exiting...")
                break
            
            if not user_input.strip():
                continue

            # Stream the response for a "typing" effect
            response = chat.send_message(user_input, stream=True)
            print("Gemini: ", end="", flush=True)
            for chunk in response:
                print(chunk.text, end="", flush=True)
            print() # Newline

        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    start_chat()
