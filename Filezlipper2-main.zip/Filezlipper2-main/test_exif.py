import sqlite3
import os
from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS

# Get a sample image file path from the database
conn = sqlite3.connect('filezipper_records.db')
cur = conn.execute("SELECT original_path FROM zipped_files WHERE arcname LIKE '%.jpg' OR arcname LIKE '%.jpeg' LIMIT 5")
image_paths = [row[0] for row in cur.fetchall()]
conn.close()

print("Checking EXIF data in sample images:\n")

for path in image_paths:
    print(f"\nFile: {os.path.basename(path)}")
    print(f"Full path: {path}")
    print(f"File exists: {os.path.exists(path)}")

    if not os.path.exists(path):
        print("  → File not found (may have been moved/deleted)")
        continue

    try:
        img = Image.open(path)
        exif = img._getexif()

        if exif is None:
            print("  -> No EXIF data found")
            continue

        print(f"  -> EXIF data found ({len(exif)} tags)")

        # Check for GPS data
        has_gps = False
        for tag_id, value in exif.items():
            tag_name = TAGS.get(tag_id, tag_id)
            if tag_name == "GPSInfo":
                has_gps = True
                print(f"  -> GPS data found!")
                if isinstance(value, dict):
                    for k, v in value.items():
                        gps_tag = GPSTAGS.get(k, k)
                        print(f"      {gps_tag}: {v}")
                break

        if not has_gps:
            print("  -> No GPS data in EXIF")

    except Exception as e:
        print(f"  -> Error reading EXIF: {e}")

print("\n" + "="*60)
print("Note: If files were moved after being zipped, location data")
print("cannot be extracted from them now.")
