
import tkinter as tk
from destinations_ui import open_destinations_window
import database

def main():
    """Main entry point for the test application."""
    # Initialize the database to ensure all tables are created.
    database._init_db()

    root = tk.Tk()
    root.title("My File Factory")
    root.geometry("400x200")

    # Button to open the destinations window
    destinations_button = tk.Button(
        root,
        text="Create/Edit Destinations",
        command=lambda: open_destinations_window(root)
    )
    destinations_button.pack(pady=20)

    # Exit button
    exit_button = tk.Button(root, text="Exit", command=root.destroy)
    exit_button.pack(side=tk.BOTTOM, pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
